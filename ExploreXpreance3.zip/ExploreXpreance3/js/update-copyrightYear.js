let currentDate = new Date();
let currentYear = currentDate.getFullYear();

document.getElementById("copyrightYear").innerText = currentYear;