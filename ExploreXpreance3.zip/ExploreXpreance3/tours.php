<?php
if(isset($_POST['submit'])){
	$Hotel_options = $_POST['hotel_options'];
	$InDate = $_POST['InDate'];
	$OutDate = $_POST['OutDate'];
	$guests = $_POST['guests'];

	$con = mysqli_connect('localhost', 'root', 'Noorullah@09', 'college');
	$query = "insert into explorexpreance4 (Hotel_options,InDate,OutDate,guests) values('$Hotel_options','$InDate','$OutDate','$guests')";
	mysqli_query($con,$query);

	if($con->affected_rows>0){
        echo '<script>alert("Successfully Uploaded");</script>';
    }else{
        echo "try again";
    }
	
}

if(isset($_POST['submit1'])){
	$hotel_options1 = $_POST['hotel_options1'];
	$InDate1 = $_POST['InDate1'];
	$OutDate1 = $_POST['OutDate1'];
	$guests1 = $_POST['guests1'];

	$con = mysqli_connect('localhost', 'root', 'Noorullah@09', 'college');
	$query1 = "insert into explorexpreance6 (hotel_options1,InDate1,OutDate1,guests1) values('$hotel_options1','$InDate1','$OutDate1','$guests1')";
	mysqli_query($con,$query1);

	if($con->affected_rows>0){
        echo '<script>alert("Successfully Uploaded ok");</script>';
    }else{
        echo "try again";
    }
	
}


?>

















<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Explore Xperience - Tours</title>

  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,700' rel='stylesheet' type='text/css'>
  <link href="css/font-awesome.min.css" rel="stylesheet">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/bootstrap-datetimepicker.min.css" rel="stylesheet">
  <link href="css/flexslider.css" rel="stylesheet">
  <link href="css/templatemo-style.css" rel="stylesheet">
  <link href="css/scrollToTop.css" rel="stylesheet">

	<!--Link to footer.css-->
	<link href="css/footer.css" rel="stylesheet">
	<!-- <link href="css/Homenavbar.css" rel="stylesheet"> -->

	<!--  Fontawesome icons -->
	<script src="https://kit.fontawesome.com/e9cf5a296c.js" crossorigin="anonymous"></script>

	<!-- <link href = "css/logo.css" rel="stylesheet"> -->
	<link
      rel="apple-touch-icon"
      sizes="180x180"
      href="./favicon/apple-touch-ic
    <link
      rel="icon"
      type="image/png"
      sizes="32x32"
      href="./favicon/favicon-32x32.png"
    />
    <link
      rel="icon"
      type="image/png"
      sizes="16x16"
      href="./favicon/favicon-16x16.png"
    />
    <link rel="manifest" href="./favicon/site.webmanifest" />

	<!-- Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <nk href="https://fonts.googleapis.com/css2?family=Changa:wght@300&family=Cinzel:wght@400;500&family=EB+Garamond&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rlink href="https://fonts.googleapis.com/css2?family=Changa:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <liel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Changa:wght@300&family=Cinzel:wght@400;500&family=EB+Garamond&family=Lato&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Changa:wght@300&family=Cinzel:wght@400;500&family=EB+Garamond&family=Lato&family=Roboto:wght@100&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Changa:wght@300&family=Cinzel:wght@400;500&family=EB+Garamond&family=Lato&family=Roboto:wght@300&display=swap" rel="stylesheet">


  <!-- Favicons -->
  <link rel="apple-touch-icon" sizes="180x180" href="./favicon/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="./favicon/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="./favicon/favicon-16x16.png">
  <link rel="manifest" href="./favicon/site.webmanifest">
  <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
      integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />



  </head>
  <body class="tm-gray-bg">

	<div class="scroll-up-btn">
        <i class="fa fa-angle-up"></i>
    </div>

  	<!-- Header -->
  	<div class="tm-header">
  		<div class="container">
  			<div class="row">
  				<div class="col-lg-6 col-md-4 col-sm-3 tm-site-name-container">
					<a href="index.php" class="tm-site-name">
						<img src = "ExploreXperience.png.png" width="130" height="70" style="margin-top: -12px;" id="logo">
						<!-- <p>Explore Xperience</p> -->
					</a>	
  				</div>
	  			<div class="col-lg-6 col-md-8 col-sm-9">
						<div class="mobile-menu-icon">
							<div class="mobile-menu-icon-wrap">
								<span class="stick stick-1"></span>
								<span class="stick stick-2"></span>
								<span class="stick stick-3"></span>
								<span class="stick stick-4"></span>
							</div>
						</div>
	  				<nav class="tm-nav">
						<ul>
							<li><a class="upper_links" href="index.php">Home</a></li>
							<li><a class="upper_links" href="about.html">About</a></li>
							<li><a id="one" href="tours.php" class="active">Our Tours</a></li>
							<li><a class="upper_links" href="contact.php">Contact</a></li>
							<li><a href="favourites.html" class="active"><i class="fa fa-heart "></i></a></li>
						</ul>
					</nav>
	  			</div>
  			</div>
  		</div>
  	</div>

	<!-- Banner -->
	<section class="tm-banner">
		<!-- Flexslider -->
		<div class="flexslider flexslider-banner">
		  <ul class="slides">
		    <li>
			    <div class="tm-banner-inner">
					<h1 class="tm-banner-title">Find <span class="tm-yellow-text">Tour</span> Programs</h1>
					<p class="tm-banner-subtitle">For Your Destinations</p>

					<a href="#tours" class="tm-banner-link">Learn More</a>	

				</div>
		      <img src="img/banner-2.jpg" />
		    </li>
		    <li>
			    <div class="tm-banner-inner">
					<h1 class="tm-banner-title">Walk <span class="tm-yellow-text">through</span> dreams</h1>
					<p class="tm-banner-subtitle">Wonderful Destinations</p>

					<a href="#special" class="tm-banner-link">Learn More</a>	

				</div>
		      <img src="img/banner-3.jpg" />
		    </li>
		    <li>
			    <div class="tm-banner-inner">
					<h1 class="tm-banner-title">Ride <span class="tm-yellow-text">your</span> journey</h1>
					<p class="tm-banner-subtitle">Enjoy the nature</p>

					<a href="#tours" class="tm-banner-link">Learn More</a>	

				</div>
		      <img src="img/banner-1.jpg" />
		    </li>
		  </ul>
		</div>
	</section>

	<!-- gray bg -->
	<section class="container tm-home-section-1" id="more">
		<div class="row" style="padding-top:80px;">
			<div class="col-lg-4 col-md-4 col-sm-6">
				<!-- Nav tabs -->
				<div class="tm-home-box-1">
					<ul class="nav nav-tabs tm-white-bg" role="tablist" id="hotelCarTabs">
					    <li role="presentation" class="active">
					    	<a href="#hotel" aria-controls="hotel" role="tab" data-toggle="tab">Hotel</a>
					    </li>
					    <li role="presentation">
					    	<a href="#car" aria-controls="car" role="tab" data-toggle="tab">Car Rental</a>
					    </li>
					</ul>

					<!-- Tab panes -->
					<div class="tab-content">
					    <div role="tabpanel" class="tab-pane fade in active tm-white-bg" id="hotel">
					    	<div class="tm-search-box effect2">
								<form action="./tours.php" method="post" class="hotel-search-form">
									<div class="tm-form-inner">
										<div class="form-group">
							            	 <select class="form-control" name="hotel_options">
							            	 	<option value="">-- Select Hotel -- </option>
							            	 	<option value="ATHIDI">DVR</option>
												<option value="">Kailash</option>
												<option value="fourseasons">Four Seasons</option>
												<option value="hilton">Our house</option>
											</select>
							          	</div>
							          	<div class="form-group">
							                <div class='input-group date' id='datetimepicker1'>
							                    <input type='text' class="form-control" placeholder="Check-in Date" name="InDate"/>
							                    <span class="input-group-addon">
							                        <span class="fa fa-calendar"></span>
							                    </span>
							                </div>
							            </div>
							          	<div class="form-group">
							                <div class='input-group date' id='datetimepicker2'>
							                    <input type='text' class="form-control" placeholder="Check-out Date" name="OutDate"/>
							                    <span class="input-group-addon">
							                        <span class="fa fa-calendar"></span>
							                    </span>
							                </div>
							            </div>
							            <div class="form-group margin-bottom-0">
							                <select class="form-control" name="guests">
							            	 	<option value="">-- Guests -- </option>
							            	 	<option value="1">1</option>
												<option value="2">2</option>
												<option value="3">3</option>
												<option value="4">4</option>
												<option value="5p">5+</option>
											</select>
							            </div>
									</div>
						            <div class="tm-yellow-gradient-bg text-center">
						            	<button type="submit" name="submit" class="tm-yellow-btn">check now</button>
						            </div>
								</form>
							</div>
					    </div>
					    <div role="tabpanel" class="tab-pane fade tm-white-bg" id="car">
							<div class="tm-search-box effect2">
								<form action="./tours.php" method="post" class="hotel-search-form">
									<div class="tm-form-inner">
										<div class="form-group">
							            	 <select name="hotel_options1" class="form-control">
							            	 	<option value="">-- Select Model -- </option>
							            	 	<option value="shangrila">BMW</option>
												<option value="chatrium">Mercedes-Benz</option>
												<option value="fourseasons">Toyota</option>
												<option value="hilton">Honda</option>
											</select>
							          	</div>
							          	<div class="form-group">
							                <div class='input-group date-time' id='datetimepicker3'>
							                    <input name="InDate1" type='text' class="form-control" placeholder="Pickup Date" />
							                    <span class="input-group-addon">
							                        <span class="fa fa-calendar"></span>
							                    </span>
							                </div>
							            </div>
							          	<div class="form-group">
							                <div class='input-group date-time' id='datetimepicker4'>
							                    <input name="OutDate1" type='text' class="form-control" placeholder="Return Date" />
							                    <span class="input-group-addon">
							                        <span class="fa fa-calendar"></span>
							                    </span>
							                </div>
							            </div>
							            <div class="form-group">
							            	 <select name="guests1" class="form-control">
							            	 	<option value="">-- Options -- </option>
							            	 	<option value="Child Seat">Child Seat</option>
												<option value="GPS Navigator">GPS Navigator</option>
												<option value="Insurance">Insurance</option>
											</select>
							          	</div>
									</div>
						            <div class="form-group tm-yellow-gradient-bg text-center">
						            	<button type="submit" name="submit1" class="tm-yellow-btn">Check Now</button>
						            </div>
								</form>
							</div>
					    </div>
					</div>
				</div>
			</div>

			<div class="col-lg-4 col-md-4 col-sm-6">
				<div class="tm-home-box-1 tm-home-box-1-2 tm-home-box-1-center effect2">
					<img src="img/index-01.jpg" alt="image" class="img-responsive">
					<a href="#">
						<div class="tm-green-gradient-bg tm-city-price-container">
							<span>Shimla</span>
							<span>₹40700</span>
						</div>	
					</a>			
				</div>				
			</div>
			<div class="col-lg-4 col-md-4 col-sm-6">
				<div class="tm-home-box-1 tm-home-box-1-2 tm-home-box-1-right effect2">
					<img src="img/index-02.jpg" alt="image" class="img-responsive">
					<a href="#">
						<div class="tm-red-gradient-bg tm-city-price-container">
							<span>Kashmir</span>
							<span>₹16200</span>
						</div>	
					</a>					
				</div>				
			</div>
		</div>

	
		<div class="section-margin-top" id="tours">
			<div class="row">				

				<div class="tm-section-header">
					<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>
					<div class="col-lg-6 col-md-6 col-sm-6"><h2 class="tm-section-title">Our Tours</h2></div>
					<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>
				</div>
			</div>
			<div class="row reveal">
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<div class="tm-tours-box-1">
						<img src="img/tours-03.jpg" alt="image" class="img-responsive">
						<div class="tm-tours-box-1-info">
							<div class="tm-tours-box-1-info-left">
								<p class="text-uppercase margin-bottom-20">Chennai tour</p>
								<p class="gray-text"><i class="fa fa-calendar"></i> 16 October 2022</p>
							</div>
							<div class="tm-tours-box-1-info-right">
								<p class="gray-text tours-1-description"><i class="fa fa-quote-left"></i> Glistening city lights, rugged ruins, legendary temples, Chennai is blessed with all <i class="fa fa-quote-right"></i></p>
							</div>
						</div>
						<div class="tm-tours-box-1-link">
							<div class="tm-tours-box-1-link-left">
								Duration: 8 days
							</div>
							<a href="#" class="tm-tours-box-1-link-right">
								₹12200							
							</a>							
						</div>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<div class="tm-tours-box-1">
						<img src="img/tours-04.jpg" alt="image" class="img-responsive">
						<div class="tm-tours-box-1-info">
							<div class="tm-tours-box-1-info-left">
								<p class="text-uppercase margin-bottom-20">Nepal tour</p>
								<p class="gray-text"><i class="fa fa-calendar"></i> 5 December 2022</p>
							</div>

							<div class="tm-tours-box-1-info-right" id="tours2">
								<p class="gray-text tours-1-description"><i class="fa fa-quote-left"></i> Known for its rich culture, traditions and some of the highest mountain peaks in the world <i class="fa fa-quote-right"></i></p>	
							</div>							

						</div>
						<div class="tm-tours-box-1-link">
							<div class="tm-tours-box-1-link-left">
								Duration: 9 days
							</div>
							<a href="#" class="tm-tours-box-1-link-right">
								₹14600								
							</a>							
						</div>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 reveal">
					<div class="tm-tours-box-1">
						<img src="img/tours-05.jpg" alt="image" class="img-responsive">
						<div class="tm-tours-box-1-info" id="tm-tours-box-1-3">
							<div class="tm-tours-box-1-info-left">
								<p class="text-uppercase margin-bottom-20">Western ghats trekking</p>
								<p class="gray-text"><i class="fa fa-calendar"></i> 20 November 2022</p>
							</div>
							<div class="tm-tours-box-1-info-right">
								<p class="gray-text tours-1-description"><i class="fa fa-quote-left"></i> Explore magnificent hills, backdrop of evergreen forests with diverse landscapes <i class="fa fa-quote-right"></i></p>
							</div>
						</div>
						<div class="tm-tours-box-1-link">
							<div class="tm-tours-box-1-link-left">
								Duration: 8 days
							</div>
							<a href="#" class="tm-tours-box-1-link-right">
								₹2000								
							</a>							
						</div>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 reveal">
					<div class="tm-tours-box-1">
						<img src="img/tours-06.jpg" alt="image" class="img-responsive">
						<div class="tm-tours-box-1-info">
							<div class="tm-tours-box-1-info-left">
								<p class="text-uppercase margin-bottom-20">Agra visit</p>
								<p class="gray-text"><i class="fa fa-calendar"></i> 18 March 2022</p>
							</div>
							<div class="tm-tours-box-1-info-right">
								<p class="gray-text tours-1-description"><i class="fa fa-quote-left"></i> Dream tour of Mughal architectural splendor with it's admiring gardens, palaces, mosques <i class="fa fa-quote-right"></i></p>
							</div>
						</div>
						<div class="tm-tours-box-1-link">
							<div class="tm-tours-box-1-link-left">
								Duration: 5 days
							</div>
							<a href="#" class="tm-tours-box-1-link-right">
								₹9700								
							</a>							
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- white bg -->
	<section class="tm-white-bg section-padding-bottom reveal">
		<div class="container">
			<div class="row">
				<div class="tm-section-header section-margin-top" id="special">
					<div class="col-lg-4 col-md-3 col-sm-3"><hr></div>
					<div class="col-lg-4 col-md-6 col-sm-6"><h2 class="tm-section-title">Special Packages</h2></div>
					<div class="col-lg-4 col-md-3 col-sm-3"><hr></div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 col-xxs-12">
					<div class="tm-tours-box-2">
						<img src="img/index-03.jpg" alt="image" class="img-responsive">
						<div class="tm-tours-box-2-info">
							<h3 class="margin-bottom-15">Goa beach</h3>
                            <div class="tm-rating"></div>
                            <p class="gray-text"><i class="fa fa-calendar"></i> <span class="happening-date"></span></p>
						</div>
						<a href="#" class="tm-tours-box-2-link">Book Now</a>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 col-xxs-12">
					<div class="tm-tours-box-2">
						<img src="img/index-04.jpg" alt="image" class="img-responsive">
						<div class="tm-tours-box-2-info">
							<h3 class="margin-bottom-15">Rajasthan desert </h3>
							<div class="tm-rating"></div>
							<p class="gray-text"><i class="fa fa-calendar"></i> <span class="happening-date"></span></p>
						</div>
						<a href="#" class="tm-tours-box-2-link">Book Now</a>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 col-xxs-12">
					<div class="tm-tours-box-2">
						<img src="img/index-05.jpg" alt="image" class="img-responsive">
						<div class="tm-tours-box-2-info">
							<h3 class="margin-bottom-15">Konkan Railway </h3>
							<div class="tm-rating"></div>
							<p class="gray-text"><i class="fa fa-calendar"></i> <span class="happening-date"></span></p>
						</div>
						<a href="#" class="tm-tours-box-2-link">Book Now</a>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 col-xxs-12">
					<div class="tm-tours-box-2">
						<img src="img/index-06.jpg" alt="image" class="img-responsive">
						<div class="tm-tours-box-2-info">
							<h3 class="margin-bottom-15">Meghalaya forests </h3>
							<div class="tm-rating"></div>
                            <p class="gray-text"><i class="fa fa-calendar"></i> <span class="happening-date"></span></p>	
						</div>						
						<a href="#" class="tm-tours-box-2-link" id="special2">Book Now</a>

					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<p class="home-description">Our special packages offer more tremendous experience for travellers </p>
				</div>
			</div>
		</div>
	</section>

	
<!-- footer -->
<footer>        
    <div class = "pages">
        <div class="menu-items">
            <a href = "index.php"><span class= "decor">Home</span></a>
            <a href = "about.html"><span class= "decor">About</span></a>
            <a href = "tours.php"><span class= "decor">Our Tours</span></a>
            <a href = "contact.php"><span class= "decor">Contact</span></a>
        </div>
    </div>
    <div class= "logo_bot">
        <img src="ExploreXperience.png.png" alt="image">
		<!-- <p>Explore Xperience</p> -->
        <h3>Subscribe our Newsletter</h3>
        <div class="newsletter">
            <input type="text"name="newsletter"value="" placeholder="Enter your email">
            <button type="submit" name="submit">Submit </button>
        </div>
        <div class="bottom-footer">
            <p id = "customer">Customer satisfaction is our first priority</p><br>
            <!-- <p>Copyrights &copy <span id="copyrightYear">2022</span> Paryatana | Designed by <a  href = "https://www.linkedin.com/in/arun-g-nayak/" style = "text-decoration: none;">Arun G Nayak</a></p> -->
        </div>
    </div>
    
    <div class = "follow">
        <h4>Follow Us</h4>
        <div class="follow-social">
            <a href = "https://www.linkedin.com/in/shaik-noorullah-12b256195/" target="_blank" class="linkedin"><i class="fa-brands fa-linkedin fa-2xl"></i></a>
            <a href = "https://www.instagram.com/noor_official_1_4_3_/" target="_blank" class="instagram"><i class="fa-brands fa-instagram fa-2xl"></i></a>
            <a href = "https://twitter.com/home" target="_blank" class="twitter"><i class="fa-brands fa-twitter fa-2xl"></i></a>
        </div>
            
    </div>
</footer>
  <!-- footer -->



	<script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>      		<!-- jQuery -->
	<script type="text/javascript" src="js/scrollToTop.js"></script>					<!-- Scroll To Top -->
  	<script type="text/javascript" src="js/moment.js"></script>							<!-- moment.js -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>					<!-- bootstrap js -->
	<script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>	<!-- bootstrap date time picker js, http://eonasdan.github.io/bootstrap-datetimepicker/ -->
	<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
   	<script type="text/javascript" src="js/templatemo-script.js"></script>      		<!-- Templatemo Script -->
	<script>
		// HTML document is loaded. DOM is ready.
		$(function() {

			$('#hotelCarTabs a').click(function (e) {
			  e.preventDefault()
			  $(this).tab('show')
			})

        	$('.date').datetimepicker({
            	format: 'MM/DD/YYYY'
            });
            $('.date-time').datetimepicker();

			// https://css-tricks.com/snippets/jquery/smooth-scrolling/
		  	$('a[href*=#]:not([href=#])').click(function() {
			    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
			      var target = $(this.hash);
			      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
			      if (target.length) {
			        $('html,body').animate({
			          scrollTop: target.offset().top
			        }, 1000);
			        return false;
			      }
			    }
		  	});
		});

		// Load Flexslider when everything is loaded.
		$(window).load(function() {
		    $('.flexslider').flexslider({
			    controlNav: false
		    });
	  	});

        // random date within next one year for special offer
        $('.happening-date').each(function() {
            var randomDate = moment().add(Math.floor(Math.random() * 365), 'days').format('MMMM Do YYYY');
            $(this).html(randomDate);
        });

        // star rating
        $('.tm-rating').each(function() {
            var rating = Math.floor(Math.random() * 5) + 1;
            var i = 0;
            for (i = 0; i < rating; i++) {
                $(this).append('<i class="fa fa-star" style="color: #fdcf00"></i>');
            }
            for (i = 0; i < (5 - rating); i++) {
                $(this).append('<i class="fa fa-star" style="color: #949494"></i>');
            }
        });

        // $('happening-date').text(moment().add(Math.floor(Math.random() * 365), 'days').format('MMMM Do YYYY'));
	</script>
	<script type="text/javascript" src="./js/onscrollReveal.js"></script>
 </body>
 </html>