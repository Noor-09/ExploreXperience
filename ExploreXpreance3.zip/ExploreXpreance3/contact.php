<?php
if(isset($_POST['submit'])){
	$name = $_POST['submit'];
	$email = $_POST['email'];
	$message = $_POST['message'];

	$con = mysqli_connect("localhost","root","Noorullah@09","college");
	$query = "insert into explorexpreance3 (name,email,message) values('$name','$email','$message')";
	mysqli_query($con,$query);

	if($con->affected_rows>0){
        echo '<script>alert("Successfully Uploaded");</script>';
    }else{
        echo "try again";
    }
	
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Explore Xperience</title>
	<link rel="icon" type="image/x-icon" href="./favicon/favicon.ico">

	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,700' rel='stylesheet'
		type='text/css'>
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-datetimepicker.min.css" rel="stylesheet">
	<link href="css/flexslider.css" rel="stylesheet">
	<link href="css/templatemo-style.css" rel="stylesheet">
	<link href="css/scrollToTop.css" rel="stylesheet">

	<!--Link to footer.css-->
	<link href="css/footer.css" rel="stylesheet">
	<!-- <link href="css/Homenavbar.css" rel="stylesheet"> -->

	<!--  Fontawesome icons -->
	<script src="https://kit.fontawesome.com/e9cf5a296c.js" crossorigin="anonymous"></script>

	<link href = "css/logo.css" rel="stylesheet">

	<!-- Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <nk href="https://fonts.googleapis.com/css2?family=Changa:wght@300&family=Cinzel:wght@400;500&family=EB+Garamond&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rlink href="https://fonts.googleapis.com/css2?family=Changa:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <liel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Changa:wght@300&family=Cinzel:wght@400;500&family=EB+Garamond&family=Lato&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Changa:wght@300&family=Cinzel:wght@400;500&family=EB+Garamond&family=Lato&family=Roboto:wght@100&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Changa:wght@300&family=Cinzel:wght@400;500&family=EB+Garamond&family=Lato&family=Roboto:wght@300&display=swap" rel="stylesheet">


  	<!-- Favicons -->
  	<link rel="apple-touch-icon" sizes="180x180" href="./favicon/apple-touch-icon.png">
  	<link rel="icon" type="image/png" sizes="32x32" href="./favicon/favicon-32x32.png">
  	<link rel="icon" type="image/png" sizes="16x16" href="./favicon/favicon-16x16.png">
  	<link rel="manifest" href="./favicon/site.webmanifest">
	<link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
      integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
</head>

<body>

	<div class="scroll-up-btn">
		<i class="fa fa-angle-up"></i>
	</div>

	<!-- Header -->
	<div class="tm-header">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-4 col-sm-3 tm-site-name-container">
					<a href="index.php" class="tm-site-name">
						<img src = "ExploreXperience.png.png" width="250" height=auto id="logo">
                        <!-- <p>Explore Xperience</p> -->
					</a>	
				</div>
				<div class="col-lg-6 col-md-8 col-sm-9">
					<div class="mobile-menu-icon">
						<div class="mobile-menu-icon-wrap">
							<span class="stick stick-1"></span>
							<span class="stick stick-2"></span>
							<span class="stick stick-3"></span>
							<span class="stick stick-4"></span>
						</div>
					</div>
					<nav class="tm-nav">
						<ul>
							<li><a class="upper_links" href="index.php">Home</a></li>
							<li><a class="upper_links" href="about.html">About</a></li>
							<li><a class="upper_links" href="tours.php">Our Tours</a></li>
							<li><a id="one" href="contact.php" class="active">Contact</a></li>
							<li><a href="favourites.html" class="active"><i class="fa fa-heart "></i></a></li>
						</ul>
					</nav>
				</div>
			</div>
		</div>
	</div>

	<!-- Banner -->
	<section class="tm-banner">
		<!-- Flexslider -->
		<div class="flexslider flexslider-banner">
		  <ul class="slides">
		    <li>
			    <div class="tm-banner-inner">
					<h1 class="tm-banner-title">Your <span class="tm-yellow-text">Special</span> Tour</h1>
					<p class="tm-banner-subtitle">For Upcoming Holidays</p>
					<a href="#more" class="tm-banner-link">Contact Us</a>
				</div>
				<img src="img/banner-3.jpg" alt="Banner 3" />
		    </li>
		  </ul>
		</div>
	</section>

	<!-- gray bg -->
	<section class="container tm-home-section-1" id="more">
		<div class="row">
			<!-- slider -->
			<div class="flexslider effect2 effect2-contact tm-contact-box-1">
				<ul class="slides">
					<li>
						<img class="contact-image-container" src="./img/contact-gif.gif">
						<div class="contact-text">
							<h2 class="slider-title"> <i class="fa-sharp fa-solid fa-plane-departure"></i> Contact for tours </h2>
							<h3 class="slider-subtitle"> Paryatna team provides special packages, festival discounts and
								best experience for the customers</h3>
							<p class="slider-description">At Paryatna, you can find the best of deals and cheap air tickets to any place you want by booking your tickets on our website or app. Being India’s leading website for hotel, flight, and holiday bookings, Paryatna helps you book flight tickets that are affordable and customized to your convenience. With customer satisfaction being our ultimate goal, we also have a 24/7 dedicated helpline to cater to our customer’s queries and concerns. Serving over 5 million happy customers, we at Paryatna are glad to fulfill the dreams of folks who need a quick and easy means to find air tickets. You can get a hold of the cheapest flight of your choice today while also enjoying the other available options for your travel needs with us.
								<br><br>
								With customer satisfaction being our ultimate goal, we also have a 24/7 dedicated helpline to cater to our customer’s queries and concerns. Serving over 5 million happy customers, we at Paryatna are glad to fulfill the dreams of folks who need a quick and easy means to find air tickets. You can get a hold of the cheapest flight of your choice today while also enjoying the other available options for your travel needs with us.</p>
							<div class="slider-social">
								<a href="https://twitter.com/" class="tm-social-icon"><i class="fa fa-twitter"></i></a>
								<a href="https://www.facebook.com/" class="tm-social-icon"><i class="fa fa-facebook"></i></a>
								<a href="https://in.pinterest.com/" class="tm-social-icon"><i class="fa fa-pinterest"></i></a>
								<a href="https://plus.google.com/" class="tm-social-icon"><i class="fa fa-google-plus"></i></a>
							</div>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</section>

	<!-- white bg -->
	<section class="section-padding-bottom">
		<div class="container">
			<div class="row">
				<div class="tm-section-header section-margin-top">
					<div class="col-lg-4 col-md-3 col-sm-3"><hr></div>
					<div class="col-lg-4 col-md-6 col-sm-6"><h2 class="tm-section-title">Contact Us</h2></div>
					<div class="col-lg-4 col-md-3 col-sm-3"><hr></div>
				</div>
			</div>
			<div class="row reveal">
				<!-- contact form -->
				<!-- <form class="tm-contact-form" action="https://formspree.io/f/myyvpqjk"
				method="POST"> -->
					<div class="col-lg-6 col-md-6">
						<div id="google-map"></div>
                    </div>

					<div class="col-lg-6 col-md-6 tm-contact-form-input">
						<h2 class="contactheading">Get in touch</h2>
						<p class="contact-para">Queries or Feedbacks? We'd love to hear from you. Here's how you can reach us...</p>
						<form action="./contact.php" method="post">
							<div class="form-group">
								<input type="text" id="contact_name" class="form-control" name="name" placeholder="Full name" />
							</div>
							<div class="form-group">
								<input type="email" id="contact_email" class="form-control" name="email" placeholder="Email" />
							</div>
							<div class="form-group">
								<textarea id="contact_message" class="form-control" rows="6"
									name="message" placeholder="Drop your querry or message here."></textarea>
							</div>
							<div class="form-group">
								<button class="tm-submit-btn" type="submit" name="submit" 
									id="email-btn">SUBMIT NOW</button>
							</div>
						</form>
					</div>
			</div>
		</div>
	</section>

	<!-- footer -->
	<footer>        
        <div class = "pages">
            <div class="menu-items">
                <a href = "index.php"><span class= "decor">Home</span></a>
                <a href = "about.html"><span class= "decor">About</span></a>
                <a href = "tours.php"><span class= "decor">Our Tours</span></a>
                <a href = "contact.php"><span class= "decor">Contact</span></a>
            </div>
        </div>
        <div class= "logo_bot">
            <img src="ExploreXperience.png.png" alt="image">
            <!-- <p>Explore Xperience</p> -->
			<h3>Subscribe our Newsletter</h3>
			<div class="newsletter">
				<input type="text"name="newsletter"value="" placeholder="Enter your email">
				<button type="submit" name="submit">Submit </button>
			</div>
			<div class="bottom-footer">
				<p id = "customer">Customer satisfaction is our first priority</p><br>
				<!-- <p>Copyrights &copy <span id="copyrightYear">2022</span> ExploreXperience | Designed by <a  href = "https://www.linkedin.com/in/arun-g-nayak/" style = "text-decoration: none;">Arun G Nayak</a></p> -->
			</div>
        </div>
        
        <div class = "follow">
            <h4>Follow Us</h4>
			<div class="follow-social">
				<a href = "https://www.linkedin.com/in/shaik-noorullah-12b256195/" target="_blank" class="linkedin"><i class="fa-brands fa-linkedin fa-2xl"></i></a>
                <a href = "https://www.instagram.com/noor_official_1_4_3_/" target="_blank" class="instagram"><i class="fa-brands fa-instagram fa-2xl"></i></a>
                <a href = "https://twitter.com/home" target="_blank" class="twitter"><i class="fa-brands fa-twitter fa-2xl"></i></a>
			</div>
                
        </div>
    </footer>
	  <!-- footer -->

	<script type="text/javascript" src="js/email.js"></script>
	<script type="text/javascript" src="js/jquery-1.11.2.min.js"></script> <!-- jQuery -->
	<script type="text/javascript" src="js/scrollToTop.js"></script> <!-- Scroll To Top -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script> <!-- bootstrap js -->
	<script type="text/javascript" src="js/jquery.flexslider-min.js"></script> <!-- flexslider js -->
	<script type="text/javascript" src="js/templatemo-script.js"></script> <!-- Templatemo Script -->
	
	<!-- Earlier code for the google map, put into a separate file-->
	<script type="text/javascript" src="js/gmap.js"></script>

	<!-- Google map -->

	<script async defer
    src="https://maps.googleapis.com/maps/api/js?
		key=AIzaSyCy6TqPsb9IY9yM0hOBnm06hnKwNG7TeW8&callback=initMap">
	</script>

	<script>
	function initMap() {
		var dumbo = {lat:28.644800, lng: 77.216721};
		var mapOptions = {
			center: dumbo,
			zoom: 6
		};
		var googlemap = new google.maps.Map(document.getElementById("google-map"), mapOptions);
		var marker = new google.maps.Marker({
                position: dumbo, // marker pointing to the location.
                map: googlemap
            });
	}

	</script> 

	<style>
	#google-map{
		width: 100%;
		height: 400px;
		background-color: grey;
	  }
	</style>
	<script type="text/javascript" src="./js/onscrollReveal.js"></script>

</body>

</html>